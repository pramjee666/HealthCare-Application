package com.demo.rest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.rest.dao.IDiagnosticTestDao;
import com.demo.rest.entity.DiagnosticTest;

@Service
public class DiagnosticTestServiceImpl implements IDiagnosticTestService {
	
	
	@Autowired
	IDiagnosticTestDao diagnostictestDao;

	@Override
	public List<DiagnosticTest> getAllDiagnosticTests() {
		return diagnostictestDao.findAll();
	}

  	@Override
	public DiagnosticTest getDiagnosticTestById(int id) {
  		Optional<DiagnosticTest> diagnostictest = diagnostictestDao.findById(id);
		return diagnostictest.get();
	}

	@Override
	public DiagnosticTest addDiagnosticTest(DiagnosticTest diagnostictest) {
		return diagnostictestDao.save(diagnostictest);
	}
	

	@Override
	public DiagnosticTest updateDiagnosticTest(int id, DiagnosticTest diagnostictest) {
		DiagnosticTest dgt = diagnostictestDao.findById(id).get();
		dgt.setTestName(diagnostictest.getTestName());
		dgt.setTestPrice(diagnostictest.getTestPrice());
		dgt.setNormalValue(diagnostictest.getNormalValue());
		dgt.setUnits(diagnostictest.getUnits());
		return diagnostictestDao.save(dgt);
		}

	@Override
	public DiagnosticTest deleteDiagnosticTestById(int id) {
		DiagnosticTest dgt = diagnostictestDao.findById(id).get();
		diagnostictestDao.deleteById(id);
		return dgt;
	}
	
}	
