package com.demo.rest.service;

import java.util.List;

import com.demo.rest.entity.DiagnosticTest;

public interface IDiagnosticTestService {

	List<DiagnosticTest> getAllDiagnosticTests();
	DiagnosticTest getDiagnosticTestById(int id);
	DiagnosticTest addDiagnosticTest(DiagnosticTest diagnostictest);
	DiagnosticTest updateDiagnosticTest(int id, DiagnosticTest diagnostictest);
	DiagnosticTest deleteDiagnosticTestById(int id);

}
