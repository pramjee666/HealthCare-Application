package com.demo.rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthcareAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
